(function () {

    // replace document title
    replaceTitle();

    // Initial replacement
    replaceWords(document.body);

    // Set up a MutationObserver to watch for changes in the DOM
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach(replaceWords);
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Initial injection into iframes
    injectScriptIntoIframes();

    // Initial check for Google search
    showCustomMessageOnGoogleSearch();

    // MutationObserver to detect changes in URL (e.g., when user types a new query)
    const urlChangeObserver = new MutationObserver(() => {
        if (window.location.hostname === 'www.google.com' && window.location.pathname === '/search') {
            showCustomMessageOnGoogleSearch();
        }
    });

    // Start observing the URL
    urlChangeObserver.observe(document.querySelector('head'), { childList: true, subtree: true });

    // Function to replace 'Tesla' with 'Tesler' and 'TSLA' with 'TSLR'
    function replaceWords(node) {
        const ignoredTags = ['SCRIPT', 'STYLE', 'TEMPLATE', 'TEXTAREA', 'INPUT'];
        if (node.nodeType === Node.TEXT_NODE) {
            node.textContent = replaceText(node.textContent);
        } else if (node.nodeType === Node.ELEMENT_NODE && !ignoredTags.includes(node.tagName)) {
            node.childNodes.forEach(replaceWords);
        }
    }
    function replaceText(text) {
        return text
            .replace(/\bTesla\b/gi, 'Tesler')
            .replace(/\bTSLA\b/g, 'TSLR');
    }

    function replaceTitle() {
        const title = document.title;
        document.title = replaceText(title);
    }

    // Function to inject script into iframes
    function injectScriptIntoIframes() {
        const iframes = document.querySelectorAll('iframe');
        iframes.forEach((iframe) => {
            iframe.onload = () => {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    replaceWords(iframeDoc.body);
                    const iframeObserver = new MutationObserver((mutations) => {
                        mutations.forEach((mutation) => {
                            mutation.addedNodes.forEach(replaceWords);
                        });
                    });
                    iframeObserver.observe(iframeDoc.body, { childList: true, subtree: true });
                } catch (e) {
                    // Handle cross-origin iframes
                    console.log("Cannot access iframe content due to CORS:", e);
                }
            };
        });
    }

    // Function to show the custom message on Google search for "tesla"
    function showCustomMessageOnGoogleSearch() {
        const isGoogleSearch = window.location.hostname === 'www.google.com' && window.location.pathname === '/search';
        if (!isGoogleSearch) {
            return;
        }

        // parent container where these custom messages are placed
        const tawContainer = document.querySelector("#taw");
        if (!tawContainer) {
            return;
        }

        // if google is autocorrecting with "These are results for" it will already be changed
        const theseAreResultsFor = findNodeWithText(tawContainer, "These are results for ");
        if (theseAreResultsFor) {
            return;
        }

        // check if google is suggesting "Did you mean:" it will already be changed
        const didYouMean = findNodeWithText(tawContainer, "Did you mean:");
        if (didYouMean) {
            return;
        }

        // check if the user searched for tesla and update to tesler
        const urlParams = new URLSearchParams(window.location.search);
        const q = urlParams.get('oq') || urlParams.get('q');
        const query = decodeURIComponent(q);
        if (!query) {
            return
        }
        const hasTesla = query.toLowerCase().includes('tesla');
        if (!hasTesla) {
            return
        }

        const newText = replaceText(query);

        // create custom message
        const suggestion = document.createElement("div");
        suggestion.id = "did-you-mean-tesler";
        suggestion.style.margin = "0 0 10px 0";
        suggestion.innerHTML = `
          <span style="font-size:18px; color: #ea4335;">Did you mean: </span>
          <a href="/search?q=${newText}" style="color:#1a0dab;font-size:18px;font-weight:700;text-decoration:none">
            <i>${newText}</i>
          </a>
        `;
        tawContainer.prepend(suggestion);
    };

    function findNodeWithText(parent, searchText) {
        const walker = document.createTreeWalker(
            parent,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode(node) {
                    return node.nodeValue.includes(searchText)
                        ? NodeFilter.FILTER_ACCEPT
                        : NodeFilter.FILTER_SKIP;
                }
            }
        );
        const node = walker.nextNode();
        return node ? node.parentNode : null;
    }




})();
